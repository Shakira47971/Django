from django.apps import AppConfig


class Task15Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'task15'
