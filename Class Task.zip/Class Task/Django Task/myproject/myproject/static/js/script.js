// static/js/script.js
document.addEventListener("DOMContentLoaded", function() {
    alert("Welcome to Task 20: Static Files Management!");
});
